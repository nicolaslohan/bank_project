from authlib.integrations.sqla_oauth2 import OAuth2ClientMixin
from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()


class OAuth2Client(db.Model, OAuth2ClientMixin):
    __tablename__ = "oauth2_clients"
    id = db.Column(db.BigInteger, primary_key=True)
    client_name = db.Column(db.String, nullable=False, unique=True)


class ClientUser(db.Model):
    __tablename__ = "client_users"
    id = db.Column(db.BigInteger, primary_key=True)
    username = db.Column(db.String, nullable=False, unique=True)
    password = db.Column(db.String, nullable=False)
    status = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, nullable=False)
    description = db.Column(db.String, nullable=True)


class BankUser(db.Model):
    __tablename__ = "bank_users"
    id = db.Column(db.BigInteger, primary_key=True)
    username = db.Column(db.String, nullable=False, unique=True)
    password = db.Column(db.String, nullable=False)
    status = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, nullable=False)
    description = db.Column(db.String, nullable=True)


class SessionToken(db.Model):
    __tablename__ = "session_tokens"
    id = db.Column(db.BigInteger, primary_key=True)
    client_user_id = db.Column(
        db.BigInteger, db.ForeignKey("client_users.id"), nullable=True
    )
    bank_user_id = db.Column(
        db.BigInteger, db.ForeignKey("bank_users.id"), nullable=True
    )
    token = db.Column(db.String, nullable=False)
    created_at = db.Column(db.DateTime)
    expires_at = db.Column(db.DateTime)
    revoked = db.Column(db.Boolean, default=False)
