from flask import Flask
from flask_cors import CORS
from .models import db
from .auth.server import configure_oauth
from .routes.oauth import oauth_bp
from .routes.api import api_bp
import os
import dotenv


def create_app():

    dotenv.load_dotenv()

    app = Flask(__name__)
    app.config["SECRET_KEY"] = os.urandom(24)
    app.config["SQLALCHEMY_DATABASE_URI"] = os.getenv("SQLALCHEMY_DATABASE_URI")
    app.config["SQLALCHEMY_DATABASE_TRACK_MODIFICATIONS"] = False

    db.init_app(app)
    configure_oauth(app)

    app.register_blueprint(oauth_bp, url_prefix="/oauth")
    app.register_blueprint(api_bp, url_prefix="/api")

    with app.app_context():
        db.create_all()  # Cria as tabelas no banco de dados

    return app
