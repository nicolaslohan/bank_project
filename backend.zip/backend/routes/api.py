from flask import Blueprint, request, jsonify
from authlib.integrations.flask_oauth2 import ResourceProtector
from authlib.oauth2.rfc6750 import BearerTokenValidator
from backend.models import SessionToken

api_bp = Blueprint("api", __name__)
require_oauth = ResourceProtector()


class TokenValidator(BearerTokenValidator):
    def authenticate_token(self, token_string):
        return SessionToken.query.filter_by(token=token_string, revoked=False).first()

    def request_invalid(self, request):
        return False

    def token_revoked(self, token):
        return token.revoked


require_oauth.register_token_validator(TokenValidator())


@api_bp.route("/me")
@require_oauth()
def me():
    """
    Endpoint to get the current user's information.
    Requires a valid OAuth token.
    """
    token = request.oauth_token
    return jsonify(
        {
            "user_id": token.client_user_id or token.bank_user_id,
            "user_type": "client" if token.client_user_id else "admin",
        }
    )
