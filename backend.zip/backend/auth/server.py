# backend/auth/server.py
from authlib.integrations.flask_oauth2 import AuthorizationServer
from authlib.oauth2.rfc6749.grants import AuthorizationCodeGrant
from authlib.oauth2.rfc6749.authenticate_client import ClientAuthentication
from backend.auth.tokens import save_token
from backend.models import OAuth2Client
from backend.auth.grant_types import PasswordGrant

authorization = AuthorizationServer()


def configure_oauth(app):

    client_auth = ClientAuthentication(
        query_client=lambda client_id: OAuth2Client.query.filter_by(
            client_id=client_id
        ).first()
    )

    authorization.init_app(
        app,
        query_client=lambda client_id: OAuth2Client.query.filter_by(
            client_id=client_id
        ).first(),
        save_token=save_token,
    )

    authorization._client_auth = client_auth
    authorization.register_grant(AuthorizationCodeGrant)
    authorization.register_grant(PasswordGrant)
