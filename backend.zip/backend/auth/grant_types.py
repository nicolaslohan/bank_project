from authlib.oauth2.rfc6749 import grants
from backend.models import ClientUser, BankUser


class PasswordGrant(grants.ResourceOwnerPasswordCredentialsGrant):
    def authenticate_user(self, username, password):
        user = ClientUser.query.filter_by(username=username).first()
        if user and user.password == password:
            return user
        user = BankUser.query.filter_by(username=username).first()
        if user and user.password == password:
            return user
        return None
